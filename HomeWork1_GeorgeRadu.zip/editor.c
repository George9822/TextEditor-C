#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct lista{
                char lit;
                struct lista *ant,*urm;
                };
typedef struct lista list;
void move(list *cap, list **cursor, int *val_crs, int nrcar, int lungime)
{
    int i,j,x,k=0;
    list *p;
    //printf("val crs=%d inainte de move,crs lista=%c\n",*val_crs,(*cursor)->lit);
    if((lungime==0)&&(*val_crs==0))  {
                    *cursor=cap;
                    *val_crs=0;
                    }
                else if(lungime>0){
                                if(((*val_crs+lungime)<nrcar)&&((*val_crs+lungime)>0)){
                                                            p=*cursor;
                                                            if(*val_crs+lungime==1){
                                                                                    //for(i=*val_crs;i<lungime+*val_crs-1;i++) p=p->urm;
                                                                                    p=p->urm;
                                                                                    *val_crs=*val_crs+lungime;
                                                                                    *cursor=p;
                                                                                    ///for(p=cap;p!=NULL;p=p->urm) printf("%c",p->lit);
                                                                                    ///printf("\n");
                                                                                    //printf("CURSORUL IN CAZUL LUNG=1 este:%c, pe poz:%d\n"(*cursor)->lit,*val_crs);
                                                                                        }
                                                               else if((*val_crs+lungime>1)&&(*val_crs+lungime<nrcar-1)){
                                                               //printf("cursorul actual este:%c,%d"(*cursor)->lit,*val_crs);
                                                                                                            for(i=*val_crs;i<*val_crs+lungime;i++){ p=p->urm;

                                                                                                                                                            }

                                                                                                                            *val_crs=*val_crs+lungime;
                                                                                                                            *cursor=p;
                                                                                                                            ///for(p=cap;p!=NULL;p=p->urm) printf("%c",p->lit);
                                                                                                                            ///printf("\n");
                                                                                                                            }

                                                                            else if(*val_crs+lungime==nrcar-1){
                                                                                    for(i=*val_crs;i<*val_crs+lungime;i++) p=p->urm;
                                                                                    *val_crs=*val_crs+lungime;
                                                                                    *cursor=p;
                                                                                    ///for(p=cap;p!=NULL;p=p->urm) printf("%c",p->lit);
                                                                                    ///printf("\n");
                                                                 //                   printf("LA MIJLOC(L-POZITIV):val crs=%d dupa move,crs lista=%c,iar ant=%c,iar urm:%c\n",*val_crs,(*cursor)->lit,(*cursor)->ant->lit,(*cursor)->urm->lit);
                                                                                            }


                                                                        }
                                    else if((*val_crs+lungime)>=nrcar){
                                                //printf("-Depaseste spre dreapta.\n");
                                                //for(i=*val_crs;i<nrcar-1;i++) p=p->urm;
                                                for(p=cap;p!=NULL;p=p->urm){
                                                                            *cursor=p;
                                                                            k++;
                                                                            }
                                                                    *val_crs=k;
                                                                    //*cursor=p;
                                                                    //printf("L-Depaseste la dr:val crs=%d dupa move,crs lista ant=%c\n",*val_crs,(*cursor)->lit);
                                                                        }
                                }
                        else if(lungime<0){
                                p=*cursor;
                                    if((*val_crs+lungime)>0){
                                            //printf("BLocat\n");
                                        for(j=*val_crs;j>=*val_crs+lungime;j--){ p=p->ant;
                                                                                   //(*val_crs)--;
                                                                                        }
                                                *val_crs=*val_crs+lungime;
                                                *cursor=p->urm;
                                    //printf("Cursorul iese daicisia:%c,poz:%d",(*cursor)->lit,*val_crs);
                                                //printf("L la mijloc cu val negativa:val crs=%d dupa move,crs lista=%c\n",*val_crs,(*cursor)->lit);
                                                            }
                                        else if((lungime+*val_crs)<0) {
                                                    //printf("-Depaseste textul spre stanga.\n");
                                                    for(j=0;j<=*val_crs-2;j++) p=p->ant;
                                                    *val_crs=0;
                                                    *cursor=cap;
                                                    //printf("L(depaseste stanga) cu val negativa:val crs=%d dupa move,crs lista=%c\n",*val_crs,(*cursor)->lit);
                                                                        }
                                                    else if((lungime+*val_crs)==0) {
                                                            //printf("-Depaseste textul spre stanga.\n");
                                                            for(j=0;j<*val_crs+lungime-1;j++) p=p->ant;
                                                            *val_crs=0;
                                                            *cursor=cap;
                                                            //printf("L(depaseste stanga cu )-egal cu poz ::cu val negativa:val crs=%d dupa move,crs lista=%c\n",*val_crs,(*cursor)->lit);
                                                                                }
                                                }
//printf("CURSORUL FINAL DUPA MUTARE ESTE:%c,%d\n",(*cursor)->lit,*val_crs);
//for(p=cap;p!=NULL;p=p->urm) printf("%c",p->lit);
//printf("\n");
//printf("/////");
}
void insert(list **cap, list **cursor, int *val_crs, int *nrcar, char sir_in[],int lungime)
{list *p,*q,*r,*s;
    int i,nrc,k=0;
    //printf("DE AICI ESTE INSERT---------------------------------\n");
    nrc=strlen(sir_in);
    ///printf("NRCCCCCC IN ISNEEEEEEEERT-----:%d\n",nrc);
    ///printf("CRS IN INSERT=%c+valcrs=%d\n",(*cursor)->lit,*val_crs);
    if(*val_crs==0) {
                                    q=(list*)malloc(sizeof(list));
                                    q->lit=sir_in[strlen(sir_in)-1];
                                    q->ant=NULL;
                                    q->urm=*cap;
                                    (*cap)->ant=q;
                                    *cap=q;
                                    //printf("val crs actuala=%d",*val_crs);
                                    (*val_crs)++;
                                    (*nrcar)++;
                                    *cursor=*cap;
                                    //printf("crs=%c,iar cap=%c",(*cursor)->lit,(*cap)->lit);
                                    for(i=strlen(sir_in)-2;i>=0;i--){
                                            q=(list*)malloc(sizeof(list));
                                            q->lit=sir_in[i];
                                            //printf("q lit pe ramura 3 este=%c\n",q->lit);
                                            q->ant=NULL;
                                            q->urm=*cap;
                                            (*cap)->ant=q;
                                            *cap=q;
                                            //*cursor=*cap;
                                            (*val_crs)++;
                                            (*nrcar)++;
                                                            }
                                    //for(p=*cap;p!=NULL;p=p->urm) printf("%c",p->lit);
                                    //printf("\n");
                                    *cursor=(*cursor)->urm;
                                   // (*val_crs)=(*val_crs)+strlen(sir_in);
                                            }
       else if(*val_crs==1){
                            r=(list*)malloc(sizeof(list));
                            r->lit=sir_in[0];
                            //printf("r lit de introdus in valcrs==1 este :%c\n",r->lit);
                            r->ant=*cap;
                            r->urm=*cursor;
                            (*cap)->urm=r;
                            (*cursor)=r;
                            (*val_crs)++;
                            (*nrcar)++;
                            for(i=1;i<strlen(sir_in);i++) {
                                    //(*cursor)=(*cursor)->ant;

                                                            s=(list*)malloc(sizeof(list));
                                                            s->lit=sir_in[i];
                                                            //printf("r lit de introdus in valcrs==1 este :%c\n",r->lit);
                                                            s->ant=(*cursor);
                                                            s->urm=(*cursor)->urm;
                                                            (*cursor)->urm->ant=s;
                                                            (*cursor)->urm=s;
                                                            (*cursor)=s;
                                                            (*val_crs)++;
                                                            (*nrcar)++;
                                                            //for(p=*cap;p!=NULL;p=p->urm) printf("%c",p->lit);
                                                            //printf("\n");
                                                            }
                            (*cursor)=(*cursor)->urm;
                                }
                else if((*val_crs>1)&&(*val_crs<*nrcar)){
                        //printf("aici intra conditia-cu l=%d\n",*l);
                        p=(*cursor)->ant;
                                for(i=0;i<strlen(sir_in);i++){
                                                                    q=(list*)malloc(sizeof(list));
                                                                    q->lit=sir_in[i];
                                                                    ///printf("q lit=%c\n",q->lit);
                                                                    q->ant=p;
                                                                    q->urm=p->urm;
                                                                    p->urm->ant=q;
                                                                    p->urm=q;
                                                                    p=q;
                                                                    (*cursor)=p;
                                                                    (*nrcar)++;
                                                                    //(*val_crs)++;
                                                                    //printf("P INSERTr1=%c\n",p->lit);
                                                                        }
                                *val_crs=*val_crs+strlen(sir_in);
                                *cursor=(*cursor)->urm;///->urm;
                                //printf("VAL CRS PE PRIMA RAM1=%d,%c\n",*val_crs,(*cursor)->lit);
                                //for(p=*cap;p!=NULL;p=p->urm) printf("%c",p->lit);
                                //printf("\n");
                                }


                    else if(*val_crs==*nrcar) {
                        *cursor=(*cursor);

                                            for(i=0;i<strlen(sir_in);i++){
                                                                            q=(list*)malloc(sizeof(list));
                                                                            q->lit=sir_in[i];
                                                                           ///printf("q lit pe ramura 2=%c\n",q->lit);
                                                                            q->ant=*cursor;
                                                                            q->urm=(*cursor)->urm;
                                                                            (*cursor)->urm=q;
                                                                            (*cursor)=q;
                                                                           (*val_crs)++;
                                                                            (*nrcar)++;
                                                                            ///printf("CURSOR INSERTr2=%c\n",(*cursor)->lit);
                                                                            }

                                           // for(p=*cap;p!=NULL;p=p->urm) printf("%c",p->lit);
                                            //printf("\n");
                                            //printf("RAMURA2-INSERT:Cursorul lista=%c,iar ant=%c,crs val=%d\n",(*cursor)->lit,(*cursor)->ant->lit,*val_crs);
                                            }
///printf("CURSORUL FINAL DUPA INSERTA ESTE:%c,ant: %c",(*cursor)->lit,(*cursor)->ant->lit);
//printf("CURSORUL FINAL DUPA INSERARE ESTE:%c, VAL:%d\n",(*cursor)->lit,*val_crs);
//for(p=*cap;p!=NULL;p=p->urm) printf("%c",p->lit);
//printf("\n");
//printf("-----");
}
void backspace(list **cap,list **cursor,int *val_crs,int *nrcar,char car[])
{
    list *p,*q;
    //char car;
    //printf("CRS IN BKSP=%c,IAR VAL=%d\n",(*cursor)->lit,*val_crs);
    if((*val_crs)==0) ;
                    else if((*val_crs>2)&&(*val_crs<*nrcar)){
                                                            p=(*cursor)->ant;
                                                            car[0]=p->lit;
                                                            car[1]='\0';
                                                            //printf("se elimina car:%c\n",car);
                                                            p->ant->urm=p->urm;
                                                            p->urm->ant=p->ant;
                                                            (*val_crs)--;
                                                            (*nrcar)--;
                                                            //for(p=*cap;p!=NULL;p=p->urm) printf("%c",p->lit);
                                                            //printf("\n");
                                                            //printf("111-CRS DUPA BKSP=%c,IAR VAL=%d\n",(*cursor)->lit,*val_crs);
                                                            }
                                    else if((*val_crs)==*nrcar) {
                                                        p=*cursor;
                                                        car[0]=p->lit;
                                                            car[1]='\0';
                                                        p->ant->urm=p->urm;
                                                        p=p->ant;
                                                        (*cursor)=p;
                                                        (*val_crs)--;
                                                        (*nrcar)--;
                                                        *cursor=p;
                                                        //for(p=*cap;p!=NULL;p=p->urm) printf("%c",p->lit);
                                                        //printf("\n");
                                                        //printf("CRS DUPA BKSP=%c,IAR VAL=%d\n",(*cursor)->lit,*val_crs);
                                                        //printf("Val crs dupa eliminareR2=%d,crs a ajuns pe ultima poz la=%c\n",*val_crs,(*cursor)->lit);
                                                            }
                                    else if(*val_crs==2){
                                                        p=*cursor;
                                                        car[0]=p->lit;
                                                            car[1]='\0';
                                                        q=*cap;
                                                        q->urm=p;
                                                        p->ant=*cap;
                                                        (*val_crs)--;
                                                        (*nrcar)--;
                                                    //printf("CRS DUPA BKSP=%c,IAR VAL=%d\n",(*cap)->lit,*val_crs);
                                                            }
                                                else if((*val_crs)==1) {
                                                            p=*cap;
                                                            car[0]=p->lit;
                                                            car[1]='\0';
                                                            p=p->urm;
                                                            p->urm->ant=p->ant;
                                                            (*cap)=p;
                                                            (*val_crs)=0;
                                                            (*nrcar)--;
                                                            ///for(p=*cap;p!=NULL;p=p->urm) printf("%c",p->lit);
                                                            ///printf("\n");
                                                           // printf("CRS DUPA BKSP=%c,IAR VAL=%d\n",(*cap)->lit,*val_crs);
                                                            //printf("Val crs dupa eliminareR3=%d\n",*val_crs);
                                                                }
//printf("---------------\n");
//printf("IN BKSP S-a eliminat caracterul:%c\n",*car);
//for(p=*cap;p!=NULL;p=p->urm) printf("%c",p->lit);
//printf("\n");
//printf("-----");
}
void del(list **cap,list **cursor,int val_crs,int *nrcar,int lungime_del,int lungime,char sir_del[])
{
    list *p,*r,*q;
    int i,j;
    *cursor=(*cursor);
    //printf("Pozitia cursorului in DELETE=%d,SI EL ESTE:%c\n",val_crs,(*cursor)->lit);
    if(lungime_del==0);
    if(val_crs==*nrcar) ;///printf("CRS este pe ultima poz,nu se poate sterge nimic.\n");
        else if((val_crs<*nrcar)&&(val_crs>1)){
                    if((lungime_del+val_crs)<*nrcar){
                                        p=*cursor;
                                        j=0;
                                        for(i=val_crs;i<val_crs+lungime_del;i++){
                                                                                    sir_del[j]=p->lit;
                                                                                    j++;
                                                                                    p=p->urm;
                                                                                    (*nrcar)--;

                                                                                        }
                                                                ///printf("p este: %c\n",p->lit);
                                                                sir_del[j]='\0';
                                                                (*cursor)->ant->urm=p;
                                                                p->ant=*cursor;
                                                                (*cursor)->urm=p->urm;
                                                                ///printf("alabala sir=%s,j=%d",sir_del,j);
                                                                ///printf("\n");
                                                                //*cursor=p;
                                                                //printf("Cursorul care iese din del:%c,poz:%d\n",(*cursor)->lit,val_crs);
                                                                //printf("q-ul meu dupa este:%c,val crs=%d,crs=%c,nrcar=%d\n",q->lit,val_crs,p->lit,*nrcar);
                                                                ///for(p=*cap;p!=NULL;p=p->urm) printf("%c",p->lit);
                                                                ///printf("\n");
                                                                //free(p);
                                                }
                            else if((lungime_del+val_crs)>=*nrcar){
                                                    ///printf("DEPASESTE LUNGIMEA CU DEL.\n");
                                                    p=(*cursor)->ant;
                                                    r=*cursor;
                                                   for(i=val_crs;i<*nrcar-1;i++) {r=r->urm;
                                                                    //printf("RUL MEEEEEU ESTEEEE:%c",r->lit);
                                                                    }
                                                    // for(i=val_crs;i<*nrcar;i++){
                                                                //                    r=r->urm;
                                                                                    //}                                                                        }
                                                     //printf("R este: %c\n",r->lit);
                                                                *nrcar=*nrcar-lungime_del;
                                                                p->urm=r->urm;
                                                                r->ant=p;
                                                                (*cursor)=p;
                                                                //printf("Cursorul dupa del depasit:%c,poz:%d\n",(*cursor)->lit,val_crs);
                                                                ///for(p=*cap;p!=NULL;p=p->urm) printf("%c",p->lit);
                                                                ///printf("\n");
                                                                free(p);
                                                                free(r);
                                                                }

                                            }
                                            else if(val_crs==0){
                                                    //if(lungime_del<*nrcar){
                                                                //p=(*cap)->ant;
                                                                q=*cursor;
                                                                for(i=val_crs;i<lungime_del+val_crs;i++) q=q->urm;
                                                                *nrcar=*nrcar-lungime_del;
                                                                ///printf("P-ul in cazul crs=0 este :%c, iar Q=%c\n",p->lit,q->lit);
                                                                (*cap)=q;
                                                                (*cap)->ant=NULL;
                                                                (*cap)->urm=q->urm;
                                                                *cursor=*cap;
                                                                ///for(p=*cap;p!=NULL;p=p->urm) printf("%c",p->lit);
                                                                        //}
                                            }
//printf("CRS DUPA DELETE:%c,poz:%d\n",(*cursor)->lit,val_crs);
///for(p=*cap;p!=NULL;p=p->urm) printf("%c",p->lit);
///printf("\n");
//printf("-----");
}
void copy(list *cap,list *cursor,int val_crs,int lungime_copy,int nrcar,char sir_copy[])
{
list *p;
int i,j,n;
///char sir_copy[1000];
///printf("Cursor in copiere este:%c\n",(cursor)->lit);

if(lungime_copy==0);
if(val_crs>=nrcar);
    else if(val_crs<nrcar){
                            if(lungime_copy+val_crs>=nrcar) {
                                p=cursor;
                                j=0;
                                    //sir_copy=(char*)malloc(nrcar*sizeof(char));
                                    /*for(p=cursor;p!=NULL;p=p->urm){
                                                                    sir_copy[j]=p->lit;
                                                                    j++;
                                                                    }*/
                                        for(i=val_crs;i<nrcar;i++){
                                                                    sir_copy[j]=p->lit;
                                                                    j++;
                                                                    p=p->urm;
                                                                    }
                                            sir_copy[j]='\0';
                                            ///printf("SIRUL COPY1:%s\n",sir_copy);
                                            //puts(sir_copy);

                                                    }
                            if(lungime_copy+val_crs<nrcar){
                                            j=0;
                                            p=cursor;
                                            //sir_copy=(char*)malloc(lungime_copy*sizeof(char));
                                                for(i=val_crs;i<lungime_copy+val_crs;i++) {

                                                                                            sir_copy[j]=p->lit;
                                                                                            //printf("J==%d si sir_copyyy===%c\n",j,sir_copy[j]);
                                                                                            j++;
                                                                                            p=p->urm;
                                                                                                    }
                                                            sir_copy[j]='\0';
                                                            ///printf("SIRUL COPY2:%s\n",sir_copy);
                                                            //puts(sir_copy);
                                                            //for(i=0;i<j;i++) printf("%c",sir_copy[i]);
                                                                    }

                            }

//printf("Cursor dupa copiere este:%c\n",(cursor)->lit);
}
void paste(list **cap,list **cursor,int *nrcar,int *val_crs,char sir_copy[])
{
    list *cap2,*p2,*q2,*p;
    int val_crs2=0;
    int nr,i;
    //insert(list **cap,list **cursor, int *val_crs, int *nrcar,char sir_copy,int strlen(sir_copy));
    //insert(cap,cursor,val_crs,nrcar,sir_copy,strlen(sir_copy));
    ///printf("Valoarea crs in paste si poz acestuia: %c, %d\n",(*cursor)->lit,*val_crs);
    nr=strlen(sir_copy);
    p2=(list*)malloc(sizeof(list));
    p2->lit=sir_copy[0];
    p2->ant=NULL;
    p2->urm=NULL;
    cap2=p2;
    for(i=1;i<nr;i++) {
                        q2=(list*)malloc(sizeof(list));
                        q2->lit=sir_copy[i];
                        q2->ant=p2;
                        q2->urm=NULL;
                        p2->urm=q2;
                        p2=q2;
                            }
   // printf("NOUA LISTA IN PASTEEE ESTE,cu lungimea:%d si lista: ",nr);
    //for(p2=cap2;p2!=NULL;p2=p2->urm) printf("%c",p2->lit);
    //printf("\n");
    insert(cap,cursor,val_crs,nrcar,sir_copy,strlen(sir_copy));
    //printf("Cursorul dupa PASTE ESTE: %c,poz:%d",(*cursor)->lit,*val_crs);
    //printf("------");
}
void undo(list **cap,list **cursor,int *nrcar,int *val_crs,int lungime,char sir_in[],char sir_copy[],int lungime_del,int lungime_copy,char sir_undo[],char car[],char sir_del[])
{
    int i,nr;
    //printf("sir undo:%s\n",sir_undo);
    if(strcmp(sir_undo,"move")==0){
                                    if(lungime==0);
                                        else if(lungime>0) move(*cap,cursor,val_crs,*nrcar,-lungime);
                                            else if(lungime<0) move(*cap,cursor,val_crs,*nrcar,lungime);
                                    //printf("Crs=%c,poz:%d\n",(*cursor)->lit,*val_crs);
                                    }
    if(strcmp(sir_undo,"insert")==0){
                                    move(*cap,cursor,val_crs,*nrcar,-strlen(sir_in));
                                    del(cap,cursor,*val_crs,nrcar,strlen(sir_in),lungime,sir_del);
                                    //for(p=*cap;p!=NULL;p=p->urm) printf("%c",p->lit);
                                    //printf("\n");
                                    }
    if(strcmp(sir_undo,"backspace")==0){
                                        insert(cap,cursor,val_crs,nrcar,car,lungime);
                                        }
    if(strcmp(sir_undo,"del")==0){  insert(cap,cursor,val_crs,nrcar,sir_del,lungime);
                                    for(i=0;i<strlen(sir_del);i++) *cursor=(*cursor)->ant;
                                    }
    if(strcmp(sir_undo,"paste")==0){
                                    nr=strlen(sir_copy);
                                    for(i=0;i<nr;i++) backspace(cap,cursor,val_crs,nrcar,car);
                                        }
}
void redo(list **cap,list **cursor,int *nrcar,int *val_crs,int lungime,char sir_in[],char sir_copy[],int lungime_del,int lungime_copy,char sir_undo[],char car[],char sir_del[],char sir_redo[])
{    if(strcmp(sir_redo,"undo")==0){
                       // printf("SIRUL PT REDO ESTE:%s,iar cel pt undo este:%s\n",sir_redo,sir_undo);
                                if(strcmp(sir_undo,"move")==0) move(*cap,cursor,val_crs,*nrcar,lungime);
                                if(strcmp(sir_undo,"insert")==0) insert(cap,cursor,val_crs,nrcar,sir_in,lungime);
                                if(strcmp(sir_undo,"backspace")==0) backspace(cap,cursor,val_crs,nrcar,car);
                                if(strcmp(sir_undo,"del")==0) del(cap,cursor,*val_crs,nrcar,strlen(sir_in),lungime,sir_del);
                                if(strcmp(sir_undo,"paste")==0) paste(cap,cursor,nrcar,val_crs,sir_copy);
                                }
}
int main(int argc, char* argv[])
{
list *cap,*p,*q,*cursor,*r;
FILE *date,*operatii,*rezultate;
char c,sir[25],sir_in[13],sir_copy[1100],sir_undo[13],car[2],sir_del[10],sir_redo[5];
int nrcar,nrop,i,lungime,val_crs=0,y=0,l=0,lungime_del,lungime_copy,k=0,z=0,lungime2;
    if((date=fopen(argv[1],"r"))==NULL) printf("Fisierul nu s-a deschis.");
    p=(list*)malloc(sizeof(list));
    fscanf(date,"%c",&p->lit);
    p->ant=NULL;
    p->urm=NULL;
    cap=p;
    c=p->lit;
    nrcar=1;
    while(fscanf(date,"%c",&c)==1){
                        q=(list*)malloc(sizeof(list));
                        q->lit=c;
                        q->ant=p;
                        q->urm=NULL;
                        p->urm=q;
                        p=q;
                        nrcar++;
                    }
    ///printf("%d\n",nrcar);
    for(p=cap;p!=NULL;p=p->urm) {
                        printf("%c",p->lit);
                            }
    fclose(date);
    printf("\n");
    if((operatii=fopen(argv[2],"r"))==NULL) printf("Fisierul nu s-a deschis.");
    fscanf(operatii,"%d",&nrop);
   // p=cap;
    cursor=cap;
    for(i=0;i<nrop;i++) {
                        fscanf(operatii,"%s",sir);
                        if(strcmp("move",sir)==0) {
                                                    fscanf(operatii,"%d",&lungime);
                                                    //printf("!!!!S-a gasit operatia : %s cu mutarea peste %d caractere.\n",sir,lungime);
                                                    move(cap,&cursor,&val_crs,nrcar,lungime);
                                                    ///printf("\n");
                                                    //printf("CURSORUL IN MAIN DUPA APELAREA FCT MOVE: %c si poz:%d\n",cursor->lit,val_crs);
                                                    }
                        if(strcmp("insert",sir)==0) {
                                                    //printf("!!!!S-a gasit operatia : %s cu sirul de introdus: ",sir);
                                                    fscanf(operatii,"%s",sir_in);
                                                    ///printf("%s\n",sir_in);
                                                    insert(&cap,&cursor,&val_crs,&nrcar,sir_in,lungime);
                                                    ///printf("-----------------------------------------------------\n");

                                                    }

                        if(strcmp("del",sir)==0) {
                                                    //printf("!!!S-a gasit operatia : %s cu nr de caractere:",sir);
                                                    fscanf(operatii,"%d",&lungime_del);
                                                    ///printf("%d\n",lungime_del);
                                                    del(&cap,&cursor,val_crs,&nrcar,lungime_del,lungime,sir_del);
                                                            }
                        if(strcmp("copy",sir)==0) {
                                                    //printf("S-a gasit operatia : %s cu nr de caractere ",sir);
                                                    fscanf(operatii,"%d",&lungime_copy);
                                                    //printf("%d\n",lungime_copy);
                                                    copy(cap,cursor,val_crs,lungime_copy,nrcar,sir_copy);
                                                            }
                        if(strcmp("paste",sir)==0) {
                                                    //printf("S-a gasit operatia : %s\n",sir);
                                                    paste(&cap,&cursor,&nrcar,&val_crs,sir_copy);
                                                    }
                        if(strcmp("backspace",sir)==0) {
                                                    ///printf("!!!!S-a gasit operatia : %s\n",sir);
                                                    backspace(&cap,&cursor,&val_crs,&nrcar,car);
                                                            }
                        if((strcmp("undo",sir)!=0)&&(strcmp("redo",sir)!=0)) strcpy(sir_undo,sir);
                        if(strcmp("undo",sir)==0) {
                                                    //printf("S-a gasit operatia : %s\n",sir);
                                                    undo(&cap,&cursor,&nrcar,&val_crs,lungime,sir_in,sir_copy,lungime_del,lungime_copy,sir_undo,car,sir_del);
                                                    }
                        if(strcmp(sir,"undo")==0) strcpy(sir_redo,sir);
                        if(strcmp("redo",sir)==0) {
                                                    //printf("S-a gasit operatia : %s\n",sir);
                                                    redo(&cap,&cursor,&nrcar,&val_crs,lungime,sir_in,sir_copy,lungime_del,lungime_copy,sir_undo,car,sir_del,sir_redo);
                                                            }
                            }
//printf("IN FORUL MARE S-A GASIT SIRUL PT UNDO=%s\n",sir_undo);
  //for(p=cap;p!=NULL;p=p->urm) printf("%c",p->lit);
  //printf("\n");
  if((rezultate=fopen(argv[3],"w"))==NULL) printf("NU s-a deschis.\n");
  for(p=cap;p!=NULL;p=p->urm) fprintf(rezultate,"%c",p->lit);
//return 666;
}
