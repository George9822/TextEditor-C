FUNCTIA MOVE-este facuta astfel incat sa plece de la primul caracter al listei,de pe pozitia 0 si sa ajunga pana la lungimea parametrului,eventual pana la sfarsitul listei in cazul in care depasea nr de caractere
	-daca n-ul introdus pt MOVE este pozitiv,cursorul se misca la dreapta de la pozitia initiala pana la n
	-daca n-ul introdus pt MOVE este negativ,cursorul se va deplasa spre stanga pana la pozitia initiala minus n-ul dorit
FUNCTIA INSERT-este facuta pentru a insera un sir de caractere in lista initial pe pozitia data de la tastatura(din functia MOVE),eventual la inceputul listei daca functia MOVE nu este apelata
	-in cazul in care cursorul se afla la pozitia zero, la capatul din stanga al listei, insereaza acolo, capul initial al listei schimbandu-se
	-in cazul de mijloc, in care cursorul nu se afla la finalul liste si nici la inceput, introducandu-se noul sir
	-in cazul de sfarsit, in care cursorul se afla pe ultima pozitie, iar dupa introducere el ramane la finalul listei nou create(la finalul sirului introdus,pe ultima pozitie)
FUNCTIA DELETE-este realizata pentru a sterge n-caractere de la pozitia in care se afla cursorul(pana la sfarsit daca n-ul este mai mare decat nr de caractere)
FUNCTIA BACKSPACE-sterge caracterul de dinaintea cursorul
FUNCTIA COPY-copiaza n-caractere de la pozitia cursorului(pana la sfarsit daca n>nr de caractere)
FUNCTIA PASTE-introduce in text ceea ce s-a copiat in functia COPY de la pozitia in care se afla cursorul
FUNCTIA UNDO-anuleaza comanda care se afla inaintea celei de "undo"
FUNCTIA REDO-reda ceea ce comanda undo a anulat